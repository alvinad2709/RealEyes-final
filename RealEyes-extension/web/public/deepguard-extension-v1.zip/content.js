const ge='@import"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap";#deepguard-panel{position:fixed;z-index:2147483647;width:300px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 8px 32px #0000001f,0 2px 8px #2a7efb14;font-family:Poppins,-apple-system,sans-serif;font-size:13px;color:#1e293b;overflow:hidden;animation:dg-slideIn .28s cubic-bezier(.34,1.56,.64,1);-webkit-user-select:none;-moz-user-select:none;user-select:none}#deepguard-panel.dragging{transition:none}@keyframes dg-slideIn{0%{opacity:0;transform:scale(.88) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}.dg-header{display:flex;align-items:center;justify-content:space-between;padding:11px 13px 10px;background:#fff}.dg-header-left{display:flex;align-items:center;gap:5px}.dg-logo{width:24px;height:24px;flex-shrink:0}.dg-logo img{width:24px;height:24px;display:block}.dg-title{font-size:13px;font-weight:700;color:#2a7efb;letter-spacing:-.2px}.dg-subtitle{font-size:9px;color:#94a3b8;font-weight:500;letter-spacing:0px;margin-top:-1px}.dg-close{width:24px;height:24px;color:#94a3b8;cursor:pointer;border:none;background:#fff;display:flex;align-items:center;justify-content:center;font-size:15px;transition:color .15s;line-height:1;padding:0}.dg-close:hover{color:#ef4444}.dg-body{padding:14px 13px}.dg-loading{display:flex;flex-direction:column;align-items:center;padding:10px 0 14px}.dg-orbital{position:relative;width:160px;height:160px}.dg-orbital-svg{width:160px;height:160px;animation:dg-orbit 1.4s linear infinite}@keyframes dg-orbit{to{transform:rotate(360deg)}}.dg-orbital-track{fill:none;stroke:#dbeafe;stroke-width:9}.dg-orbital-comet{fill:none;stroke:url(#dg-comet-grad);stroke-width:9;stroke-linecap:round}.dg-orbital-center{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center}.dg-orbital-label{font-size:15px;font-weight:600;color:#475569;letter-spacing:-.2px}.dg-score-wrapper{display:flex;flex-direction:column;align-items:center;gap:10px;margin-bottom:13px}.dg-ring-container{position:relative;width:120px;height:120px;flex-shrink:0}.dg-ring-svg{width:120px;height:120px;transform:rotate(-90deg);display:block}.dg-ring-track{fill:none;stroke:#f1f5f9;stroke-width:8}.dg-ring-fill{fill:none;stroke-width:8;stroke-linecap:round}.dg-ring-label{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px}.dg-ring-score{font-size:26px;font-weight:800;letter-spacing:-1px;line-height:1}.dg-ring-pct{font-size:10px;color:#94a3b8;font-weight:500}.dg-score-meta{display:flex;flex-direction:column;align-items:center;gap:4px}.dg-verdict{display:inline-flex;align-items:center;gap:5px;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.3px}.dg-verdict.fake{background:#fee2e2;border:1px solid #fca5a5;color:#ef4444}.dg-verdict.real{background:#dcfce7;border:1px solid #86efac;color:#16a34a}.dg-bars{display:flex;flex-direction:column;gap:7px;margin-bottom:12px}.dg-bar-row{display:flex;flex-direction:column;gap:3px}.dg-bar-label{display:flex;justify-content:space-between;font-size:10px;color:#94a3b8;font-weight:500}.dg-bar-label span:last-child{font-weight:700;color:#64748b}.dg-bar-track{height:5px;border-radius:3px;background:#f1f5f9;overflow:hidden}.dg-bar-fill{height:100%;border-radius:3px;width:0%;transition:width 1.2s cubic-bezier(.4,0,.2,1)}.dg-bar-fill.fake{background:linear-gradient(90deg,#ef4444,#f97316)}.dg-bar-fill.real{background:linear-gradient(90deg,#22c55e,#2a7efb)}.dg-section-label{font-size:9.5px;font-weight:600;color:#cbd5e1;text-transform:uppercase;letter-spacing:.6px;margin-bottom:7px}.dg-analysis-list{display:flex;flex-direction:column;gap:5px}.dg-analysis-item{display:flex;align-items:flex-start;gap:6px;font-size:10.5px;color:#64748b;line-height:1.4}.dg-check{width:14px;height:14px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:8px;flex-shrink:0;margin-top:1px}.dg-check.ok{background:#dcfce7;color:#16a34a}.dg-check.warn{background:#fee2e2;color:#ef4444}.dg-footer-bar{padding:7px 13px;border-top:1px solid #f1f5f9;font-size:9.5px;color:#cbd5e1;background:#f8fafc;font-weight:500}.dg-divider{height:1px;background:#f1f5f9;margin:12px 0}.dg-countdown{display:flex;flex-direction:column;align-items:center;gap:8px;padding:6px 0}.dg-countdown-num{font-size:48px;font-weight:800;color:#2a7efb;line-height:1;animation:dg-countPulse 1s ease infinite}@keyframes dg-countPulse{0%,to{transform:scale(1);opacity:1}50%{transform:scale(1.06);opacity:.85}}.dg-countdown-label{font-size:11.5px;color:#64748b;font-weight:500;text-align:center}.dg-recording{display:flex;flex-direction:column;align-items:center;gap:10px;padding:6px 0}.dg-rec-dot{width:16px;height:16px;border-radius:50%;background:#ef4444;animation:dg-recPulse 1s ease infinite}@keyframes dg-recPulse{0%{box-shadow:0 0 #ef444480}70%{box-shadow:0 0 0 10px #ef444400}to{box-shadow:0 0 #ef444400}}.dg-rec-label{font-size:12px;font-weight:600;color:#ef4444}.dg-rec-time{font-size:10px;color:#94a3b8;font-weight:500}.dg-rec-bar{width:90%;height:4px;border-radius:2px;background:#fee2e2;overflow:hidden}.dg-rec-bar-fill{height:100%;background:linear-gradient(90deg,#fca5a5 25%,#ef4444,#fca5a5 75%);background-size:200% 100%;border-radius:2px;animation:dg-shimmerMove 1.4s infinite}',y="deepguard-panel",j="deepguard-panel-styles";function ue(){if(document.getElementById(j))return;const e=document.createElement("style");e.id=j,e.textContent=ge,document.head.appendChild(e)}function pe(e){return`
    <div class="dg-header">
      <div class="dg-header-left">
        <div class="dg-logo"><img src="${e}" alt="DeepGuard" /></div>
        <div>
          <div class="dg-title">DeepGuard</div>
        </div>
      </div>
      <button class="dg-close" id="dg-close-btn" title="Close">✕</button>
    </div>
  `}function fe(){return`
    <div class="dg-loading">
      <div class="dg-orbital">
        <svg class="dg-orbital-svg" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="dg-comet-grad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%"   stop-color="#2A7EFB" stop-opacity="0"/>
              <stop offset="60%"  stop-color="#2A7EFB" stop-opacity="0.6"/>
              <stop offset="100%" stop-color="#2A7EFB" stop-opacity="1"/>
            </linearGradient>
          </defs>
          <circle class="dg-orbital-track" cx="80" cy="80" r="68"/>
          <circle class="dg-orbital-comet" cx="80" cy="80" r="68"
            stroke-dasharray="140 290"
          />
        </svg>
        <div class="dg-orbital-center">
          <span class="dg-orbital-label">Loading</span>
        </div>
      </div>
    </div>
  `}function T(e,t){var o;ue(),O();const i=chrome.runtime.getURL("icons/icon128.png"),n=document.createElement("div");if(n.id=y,t)n.style.left=`${Math.min(t.x,window.innerWidth-320)}px`,n.style.top=`${Math.min(t.y,window.innerHeight-100)}px`;else if(e){const a=e.getBoundingClientRect(),r=Math.min(a.right+10,window.innerWidth-320),l=Math.max(a.top,10);n.style.left=`${r+window.scrollX}px`,n.style.top=`${l+window.scrollY}px`,n.style.position="absolute"}else n.style.right="20px",n.style.top="80px";return n.innerHTML=`
    ${pe(i)}
    <div class="dg-body">${fe()}</div>
  `,document.body.appendChild(n),me(n),(o=document.getElementById("dg-close-btn"))==null||o.addEventListener("click",O),n}function O(){var e;(e=document.getElementById(y))==null||e.remove()}function L(e){const t=document.querySelector(`#${y} .dg-body`);t&&(t.innerHTML=`
    <div class="dg-countdown">
      <div class="dg-countdown-num">${e}</div>
      <div class="dg-countdown-label">Recording starts in ${e} second${e!==1?"s":""}</div>
    </div>
  `)}function R(e,t){const i=document.querySelector(`#${y} .dg-body`);if(!i)return;const n=Math.max(0,t-e),o=e>=t;i.innerHTML=`
    <div class="dg-recording">
      <div class="dg-rec-dot" ${o?'style="background-color: #f59e0b; animation: none;"':""}></div>
      <div class="dg-rec-label">${o?"⏳ Analyzing AI...":"🎙️ Recording…"}</div>
      <div class="dg-rec-time">${o?"Please wait":n+"s remaining"}</div>
      <div class="dg-rec-bar">
        <div class="dg-rec-bar-fill" style="width: ${o?"100":e/t*100}%"></div>
      </div>
    </div>
  `}function _(e){const t=document.querySelector(`#${y} .dg-body`);if(!t)return;const i=e.label==="FAKE",n=e.confidence,o=52,a=2*Math.PI*o,r=a*(1-n/100),l=i?"#ef4444":"#22c55e";t.innerHTML=`
    <div class="dg-score-wrapper">
      <div class="dg-ring-container">
        <svg class="dg-ring-svg" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="dg-ring-grad-fake" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%"   stop-color="#f97316"/>
              <stop offset="100%" stop-color="#ef4444"/>
            </linearGradient>
            <linearGradient id="dg-ring-grad-real" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%"   stop-color="#22c55e"/>
              <stop offset="100%" stop-color="#2A7EFB"/>
            </linearGradient>
          </defs>
          <circle class="dg-ring-track" cx="60" cy="60" r="${o}"/>
          <circle
            class="dg-ring-fill"
            id="dg-ring-anim"
            cx="60" cy="60" r="${o}"
            stroke="${i?"url(#dg-ring-grad-fake)":"url(#dg-ring-grad-real)"}"
            stroke-dasharray="${a}"
            stroke-dashoffset="${a}"
          />
        </svg>
        <div class="dg-ring-label">
          <span class="dg-ring-score" id="dg-score-num" style="color:${l}">0</span>
          <span class="dg-ring-pct">% confidence</span>
        </div>
      </div>

      <div class="dg-score-meta">
        <div class="dg-verdict ${i?"fake":"real"}">
          ${i?"⚠ DEEPFAKE":"✓ AUTHENTIC"}
        </div>
      </div>
    </div>

    <div class="dg-bars">
      <div class="dg-bar-row">
        <div class="dg-bar-label">
          <span>Fake Probability</span>
          <span id="dg-fake-pct">0%</span>
        </div>
        <div class="dg-bar-track">
          <div class="dg-bar-fill fake" id="dg-fake-bar" style="width:0%"></div>
        </div>
      </div>
      <div class="dg-bar-row">
        <div class="dg-bar-label">
          <span>Real Probability</span>
          <span id="dg-real-pct">0%</span>
        </div>
        <div class="dg-bar-track">
          <div class="dg-bar-fill real" id="dg-real-bar" style="width:0%"></div>
        </div>
      </div>
    </div>

    <div class="dg-divider"></div>

    <div class="dg-section-label">Detailed Analysis</div>
    <div class="dg-analysis-list">
      ${e.details.analysis_points.map(c=>`
        <div class="dg-analysis-item">
          <div class="dg-check ${i?"warn":"ok"}">${i?"!":"✓"}</div>
          <span>${c}</span>
        </div>`).join("")}
    </div>
  `,requestAnimationFrame(()=>{requestAnimationFrame(()=>{const c=document.getElementById("dg-ring-anim");c&&(c.style.transition="stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1)",c.style.strokeDashoffset=String(r));const H=document.getElementById("dg-fake-bar"),q=document.getElementById("dg-real-bar");H&&(H.style.width=`${e.scores.FAKE}%`),q&&(q.style.width=`${e.scores.REAL}%`);const oe=1200,re=performance.now(),E=document.getElementById("dg-score-num"),k=document.getElementById("dg-fake-pct"),A=document.getElementById("dg-real-pct");function ae(D){return 1-Math.pow(1-D,3)}function V(D){const se=D-re,W=Math.min(se/oe,1),B=ae(W),de=B*n,le=B*e.scores.FAKE,ce=B*e.scores.REAL;E&&(E.textContent=de.toFixed(1)),k&&(k.textContent=le.toFixed(1)+"%"),A&&(A.textContent=ce.toFixed(1)+"%"),W<1?requestAnimationFrame(V):(E&&(E.textContent=n.toFixed(1)),k&&(k.textContent=e.scores.FAKE.toFixed(1)+"%"),A&&(A.textContent=e.scores.REAL.toFixed(1)+"%"))}requestAnimationFrame(V)})})}function z(e){const t=document.querySelector(`#${y} .dg-body`);t&&(t.innerHTML=`
    <div style="text-align:center; padding: 14px 0; color: #ef4444;">
      <div style="font-size: 26px; margin-bottom: 8px;">⚠️</div>
      <div style="font-size: 12px; font-weight: 700; margin-bottom: 4px; color:#1e293b;">Analysis Failed</div>
      <div style="font-size: 10.5px; color: #94a3b8;">${e}</div>
    </div>
  `)}function me(e){let t=0,i=0,n=0,o=0;e.addEventListener("mousedown",a=>{if(a.target.id==="dg-close-btn")return;e.classList.add("dragging"),t=a.clientX,i=a.clientY,n=parseInt(e.style.left||"0",10),o=parseInt(e.style.top||"0",10);const r=c=>{e.style.left=`${n+c.clientX-t}px`,e.style.top=`${o+c.clientY-i}px`,e.style.right="auto"},l=()=>{e.classList.remove("dragging"),document.removeEventListener("mousemove",r),document.removeEventListener("mouseup",l)};document.addEventListener("mousemove",r),document.addEventListener("mouseup",l),a.preventDefault()})}const C="data-dg-injected",K=80;let v=!1,p=null;function Z(){v||(v=!0,xe(),ye())}function he(){v=!1,p==null||p.disconnect(),p=null,document.querySelectorAll(`[${C}]`).forEach(e=>{e.removeAttribute(C)}),document.querySelectorAll(".dg-guard-badge").forEach(e=>e.remove()),O()}function xe(){document.querySelectorAll("img").forEach(e=>{e.complete&&e.naturalWidth>0?S(e):e.addEventListener("load",()=>S(e),{once:!0})})}function S(e){if(!v||e.hasAttribute(C)||e.width<K||e.height<K||!e.src||e.src.startsWith("data:image/svg"))return;e.setAttribute(C,"true");const t=document.createElement("div");t.className="dg-guard-badge",t.style.cssText=`
    position: absolute;
    bottom: 6px;
    right: 6px;
    z-index: 2147483647;
    cursor: pointer;
    transition: transform 0.15s ease;
  `;let i;try{i=`<img src="${chrome.runtime.getURL("icons/icon128.png")}" alt="DeepGuard" style="width:18px;height:20px;display:block;border-radius:4px;" />`}catch{i='<svg viewBox="0 0 24 24" width="18" height="20" fill="#2A7EFB"><path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm-1.06 13.54L7.4 12l1.41-1.41 2.12 2.12 4.24-4.24 1.41 1.41-5.64 5.66z"/></svg>'}t.innerHTML=i,t.addEventListener("mouseenter",()=>{t.style.transform="scale(1.1)"}),t.addEventListener("mouseleave",()=>{t.style.transform="scale(1)"}),t.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),ve(e)});const n=e.parentElement;n&&(getComputedStyle(n).position==="static"&&(n.style.position="relative"),n.appendChild(t))}function ye(){p=new MutationObserver(e=>{if(v)for(const t of e)t.addedNodes.forEach(i=>{var o;if(i.nodeType!==1)return;const n=i;n.tagName==="IMG"&&S(n),(o=n.querySelectorAll)==null||o.call(n,"img").forEach(a=>S(a))})}),p.observe(document.body,{childList:!0,subtree:!0})}async function ve(e){T(e);try{let t;try{t=await be(e.currentSrc||e.src)}catch{t=await we(e)}_(t)}catch(t){z(t instanceof Error?t.message:"Analysis failed.")}}function be(e){return new Promise((t,i)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_URL",payload:{url:e}},n=>{if(chrome.runtime.lastError){i(chrome.runtime.lastError);return}n!=null&&n.success?t(n):i(new Error((n==null?void 0:n.error)||"Backend error"))})})}function we(e){const t=document.createElement("canvas");t.width=e.naturalWidth||e.width,t.height=e.naturalHeight||e.height;const i=t.getContext("2d");if(!i)throw new Error("Canvas not supported");i.drawImage(e,0,0);const n=t.toDataURL("image/png");return new Promise((o,a)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_BASE64",payload:{base64:n}},r=>{if(chrome.runtime.lastError){a(chrome.runtime.lastError);return}r!=null&&r.success?o(r):a(new Error((r==null?void 0:r.error)||"Backend error"))})})}const Ee="dg-region-overlay",ke="dg-select-box",U="dg-cursor-style";let b=!1,f=0,m=0,u=null,s=null,M=null;function Ae(){X(),Me(),$e()}function Me(){let e=document.getElementById(U);e||(e=document.createElement("style"),e.id=U,document.head.appendChild(e)),e.textContent=`
    html, html * {
      cursor: crosshair !important;
    }
  `}function Ie(){var e;(e=document.getElementById(U))==null||e.remove()}function $e(){u=document.createElement("div"),u.id=Ee,u.style.cssText=`
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    user-select: none;
  `,s=document.createElement("div"),s.id=ke,s.style.cssText=`
    position: fixed;
    border: 2px solid #6C63FF;
    background: rgba(108,99,255,0.08);
    display: none;
    pointer-events: none;
    z-index: 2147483647;
    border-radius: 4px;
    box-shadow: 0 0 0 1px rgba(108,99,255,0.3), inset 0 0 20px rgba(108,99,255,0.05);
  `,document.body.appendChild(s),u.addEventListener("mousedown",Le),document.addEventListener("mousemove",J),document.addEventListener("mouseup",Q),document.body.appendChild(u),document.addEventListener("keydown",ee)}function Le(e){b=!0,f=e.clientX,m=e.clientY,s&&(s.style.display="block",s.style.left=`${f}px`,s.style.top=`${m}px`,s.style.width="0",s.style.height="0"),e.preventDefault()}function J(e){if(!b||!s)return;const t=Math.min(e.clientX,f),i=Math.min(e.clientY,m),n=Math.abs(e.clientX-f),o=Math.abs(e.clientY-m);s.style.left=`${t}px`,s.style.top=`${i}px`,s.style.width=`${n}px`,s.style.height=`${o}px`}async function Q(e){if(!b)return;b=!1;const t=Math.min(e.clientX,f),i=Math.min(e.clientY,m),n=Math.abs(e.clientX-f),o=Math.abs(e.clientY-m);X(),!(n<20||o<20)&&(T(null,{x:Math.min(t+n+12,window.innerWidth-340),y:Math.max(i,10)}),await Re(t,i,n,o))}function ee(e){e.key==="Escape"&&X()}async function Re(e,t,i,n){let o=0;const a=5,r=async()=>{if(o++,o>a){Y();return}try{const l=await Ce(e,t,i,n),c=await Se(l);_(c)}catch(l){z(l instanceof Error?l.message:"Region capture failed"),Y()}};await r(),M=window.setInterval(r,2e3)}function Y(){M!==null&&(clearInterval(M),M=null)}async function Ce(e,t,i,n){return new Promise((o,a)=>{chrome.runtime.sendMessage({type:"CAPTURE_REGION",payload:{x:e,y:t,w:i,h:n}},r=>{if(chrome.runtime.lastError)return a(new Error(chrome.runtime.lastError.message));r!=null&&r.base64?o(r.base64):a(new Error((r==null?void 0:r.error)||"Capture failed"))})})}async function Se(e){return new Promise((t,i)=>{chrome.runtime.sendMessage({type:"ANALYZE_IMAGE_BASE64",payload:{base64:e}},n=>{if(chrome.runtime.lastError)return i(new Error(chrome.runtime.lastError.message));n!=null&&n.success?t(n):i(new Error((n==null?void 0:n.error)||"Analysis failed"))})})}function X(){b=!1,Y(),u==null||u.remove(),u=null,s==null||s.remove(),s=null,Ie(),document.removeEventListener("mousemove",J),document.removeEventListener("mouseup",Q),document.removeEventListener("keydown",ee)}const P=10;let I=null;chrome.runtime.onMessage.addListener(e=>{e.type==="AUDIO_CAPTURE_RESULT"&&(I&&(clearInterval(I),I=null),e.success&&e.result?_(e.result):z(e.error||"Audio capture failed. Make sure the tab is playing audio."))});function Te(){T(null,{x:window.innerWidth-350,y:80});let e=5;L(e);const t=setInterval(()=>{e--,e<=0?(clearInterval(t),_e()):L(e)},1e3)}function _e(){R(0,P);let e=0;I=setInterval(()=>{e++,R(e,P)},1e3),chrome.runtime.sendMessage({type:"START_TAB_AUDIO_CAPTURE",payload:{duration:P}},()=>{chrome.runtime.lastError})}const F=15,ze="dg-video-overlay",De="dg-video-select-box",N="dg-video-cursor-style";let w=!1,h=0,x=0,g=null,d=null,$=null;chrome.runtime.onMessage.addListener(e=>{e.type==="VIDEO_CAPTURE_RESULT"&&($&&(clearInterval($),$=null),e.success&&e.result?_(e.result):z(e.error||"Video capture failed. Make sure the tab is active."))});function Be(){G(),Pe(),Oe()}function Pe(){let e=document.getElementById(N);e||(e=document.createElement("style"),e.id=N,document.head.appendChild(e)),e.textContent=`
    html, html * {
      cursor: crosshair !important;
    }
  `}function Fe(){var e;(e=document.getElementById(N))==null||e.remove()}function Oe(){g=document.createElement("div"),g.id=ze,g.style.cssText=`
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    user-select: none;
  `;const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #2A7EFB, #1a5dc7);
    color: white;
    padding: 10px 24px;
    border-radius: 12px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px;
    font-weight: 600;
    z-index: 2147483647;
    pointer-events: none;
    box-shadow: 0 4px 20px rgba(42,126,251,0.4);
    display: flex;
    align-items: center;
    gap: 8px;
  `,e.innerHTML=`
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
    </svg>
    Drag to select the video area to record • Press ESC to cancel
  `,g.appendChild(e),d=document.createElement("div"),d.id=De,d.style.cssText=`
    position: fixed;
    border: 2px solid #2A7EFB;
    background: rgba(42,126,251,0.08);
    display: none;
    pointer-events: none;
    z-index: 2147483647;
    border-radius: 4px;
    box-shadow: 0 0 0 1px rgba(42,126,251,0.3), inset 0 0 20px rgba(42,126,251,0.05);
  `,document.body.appendChild(d),g.addEventListener("mousedown",Ue),document.addEventListener("mousemove",te),document.addEventListener("mouseup",ne),document.body.appendChild(g),document.addEventListener("keydown",ie)}function Ue(e){w=!0,h=e.clientX,x=e.clientY,d&&(d.style.display="block",d.style.left=`${h}px`,d.style.top=`${x}px`,d.style.width="0",d.style.height="0"),e.preventDefault()}function te(e){if(!w||!d)return;const t=Math.min(e.clientX,h),i=Math.min(e.clientY,x),n=Math.abs(e.clientX-h),o=Math.abs(e.clientY-x);d.style.left=`${t}px`,d.style.top=`${i}px`,d.style.width=`${n}px`,d.style.height=`${o}px`}function ne(e){if(!w)return;w=!1;const t=Math.min(e.clientX,h),i=Math.min(e.clientY,x),n=Math.abs(e.clientX-h),o=Math.abs(e.clientY-x);if(G(),n<20||o<20)return;const a=Math.max(document.documentElement.clientWidth||0,window.innerWidth||0),r=Math.max(document.documentElement.clientHeight||0,window.innerHeight||0),l={x:Math.max(0,t/a),y:Math.max(0,i/r),w:Math.min(1,n/a),h:Math.min(1,o/r)};T(null,{x:Math.min(t+n+12,window.innerWidth-340),y:Math.max(i,10)}),Ye(l)}function ie(e){e.key==="Escape"&&G()}function Ye(e){let t=5;L(t);const i=setInterval(()=>{t--,t<=0?(clearInterval(i),Ne(e)):L(t)},1e3)}function Ne(e){R(0,F);let t=0;$=setInterval(()=>{t++,R(t,F)},1e3),chrome.runtime.sendMessage({type:"START_TAB_VIDEO_CAPTURE",payload:{duration:F,bbox:e}},()=>{chrome.runtime.lastError})}function G(){w=!1,g==null||g.remove(),g=null,d==null||d.remove(),d=null,Fe(),document.removeEventListener("mousemove",te),document.removeEventListener("mouseup",ne),document.removeEventListener("keydown",ie)}chrome.runtime.onMessage.addListener((e,t,i)=>{switch(e.type){case"SCANNER_ON":Z();break;case"SCANNER_OFF":he();break;case"START_REGION_SELECT":Ae();break;case"START_AUDIO_RECORD":Te();break;case"START_VIDEO_RECORD":Be();break}return i({ok:!0}),!0});try{chrome.storage.session.get("scannerOn",e=>{chrome.runtime.lastError||e!=null&&e.scannerOn&&Z()})}catch{}
